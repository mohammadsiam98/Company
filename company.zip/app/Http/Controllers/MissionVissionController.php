<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class MissionVissionController extends Controller
{
    //
    public function aim()
    {
        return view('pages.missionVission.missionVission');
    }
}
